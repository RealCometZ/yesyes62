( Keep in mind that this cheat is undetected, therefore it needs to be updated frequently.
so i will be updating this cheat every 1-2 week, once the cheat updated the token will change and the loader build will change (for extra security) and to support the one updating it.
BUT! you do not have to redownload IF you doesnt want the latest undetected version
but IF you want it 100% undetected everytime you must check this website for updates, there will be a version counter under the download on the website button so you can check if its updated or not :) )



i do not own this cheat i just make it undetected :)
credits to owner :)


HOW TO INSTALL:
1.Download from: Cheatsaint.weebly.com
2.Unextract the file
3.run the "loader.exe" with csgo open
4.enjoy :)

